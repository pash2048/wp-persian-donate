<?php
echo $result;