<?php

/*
Plugin Name: Easy-pay
Plugin URI: http://siteamoz.ir
Description: افزونه آسان پرداخت سایت آموز
Version: 1.0.0
Author: Javad Jazandari
Author URI: http://jazandari.ir
*/

define('EZP_DB_VERIZON',1 );

defined ('ABSPATH') || exit('No Direct Access.');

define('EZP_DIR',  plugin_dir_path(__FILE__));

define('EZP_URL', plugin_dir_url(__FILE__));

define('EZP_CSS_URL',  trailingslashit(EZP_URL.'assets/css'));

define('EZP_JS_URL',  trailingslashit(EZP_URL.'assets/js'));

define('EZP_IMG_URL',  trailingslashit(EZP_URL.'assets/mg'));

define('EZP_INC_DIR',  trailingslashit(EZP_DIR.'include'));

define('EZP_ADMIN_DIR',  trailingslashit(EZP_DIR.'admin'));

define('EZP_TPL_DIR',  trailingslashit(EZP_DIR.'tamplate'));

register_activation_hook(__FILE__,'ezp_activation' );
register_deactivation_hook(__FILE__,'ezp_deactivation' );


include EZP_INC_DIR.'shortcodes.php';

include EZP_INC_DIR.'frontend.php';

if(is_admin()){

    require EZP_ADMIN_DIR.'page.php';
    
    require EZP_ADMIN_DIR.'menu.php';

    include EZP_INC_DIR.'backend.php';
    
}

function ezp_activation(){

    $current_db_verizon=get_option('ezp_db_verizon');

    if (EZP_DB_VERIZON>intval($current_db_verizon)){

        require EZP_INC_DIR.'upgarade.php';
        update_option('ezp_db_verizon',EZP_DB_VERIZON );

    }

}
function ezp_deactivation(){



}
