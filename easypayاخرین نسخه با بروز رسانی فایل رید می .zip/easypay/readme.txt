===  parsian donate ===

Contributors: pash2048
Donate link: http://jazandari.ir/
Tags: donate, parsian,zarinpal,faragate,farapayamak
Requires at least: 3.5
Tested up to: 4.5.3
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin is for danote your site with faragate and zarinpal Network gateway  and send sms with fara payamak.

== Description ==

</p> parsian Donate plugin helps to get donations from faragate and zarinpal Network gateway systems,</p>
<p>It has a user-friendly and simple interface which allows to place the donate button anywhere on the site and when user donate your site plugin send one sms to him and we use fara payamek sms Service for it.</p>
<p>you can Customize sms txt and manage all payments in wordpress dashbord.</p>



<h4>Features</h4>

<ul>
<li>Customize payment form (change their size, type, custom image).</li>
<li>Support for SMS services more</li>
<li>Support more Portal Pay</li>
<li>Translating into more languages</li>
</ul>


== Installation ==

<ol>
<li>Upload plugin <code>parsian donate</code> folder to the <code>/wp-content/plugins/</code> directory.</li>
<li>Activate the plugin using the 'asan pardakht' menu in your WordPress admin panel.</li>
<li>for show paymant for use [ezpay_form] shortcode.</li>
</ol>

== Frequently Asked Questions ==


= I have some problems with the plugin's work. What Information should I provide to receive proper support? =

you can contact me and ask your Question from me in (<a href="http://jazandari.ir/?page_id=13" rel="nofollow">http://jazandari.ir/?page_id=13</a>


== Screenshots ==

1. plugin settings page.
2. pulgin payment form.
3. plugin show paymenyt page.
