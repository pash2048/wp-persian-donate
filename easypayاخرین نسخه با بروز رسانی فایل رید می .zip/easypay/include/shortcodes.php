<?php

add_shortcode('ezpay_form','ezpay_form' );


function ezpay_form(){
    $has_error=false;
    $massage="";

    $status= 0;


    if(isset($_GET['bank'])){

        $bank=$_GET['bank'];
        switch ($bank){

            case 'zarinpal';

               $return_result=zarinpal_verify();
                $status= 1;
                break;
            case 'faragate';
                $return_result=faragate_verify();
                $status= 1;
                break;
            default;
                break;

        }
    }



    $ezp_active=intval(get_option('ezp_active'));
    if (!$ezp_active){
        
        return 'فرم پرداخت در حال حاضر در دسترس نمی باشد.';
    }
    
    if(isset($_POST['ezpay_submit'])){

        wp_verify_nonce($_POST['ezp_nonce'],'ezp_payment') || wp_die("درخواست شما نا معتبر می باشد.");



        $fullname=sanitize_text_field($_POST['fullname']);
        $email=sanitize_text_field($_POST['email']);
        $mobile=sanitize_text_field($_POST['mobile']);
        $amount=intval($_POST['amount']);
        $description=sanitize_text_field($_POST['description']);
        $bank=esc_sql($_POST['bank']);
        $date=date('y-m-d H:I:S');

        foreach($_POST as $key=>$value){
            if(empty($value)){

                $has_error=true;
                $massage="پرکردن تمامی فیلد ها الزامی می باشد!";

            }
        }
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)){

            $has_error=true;
            $massage="لطفا ایمیل معتبر وارد کنید!";
        }
        
        if(!$amount){

            $has_error=true;
            $massage="مقدار مبلغ حتما باید به صورت عددی وارد شود!";

        }
        if(!$has_error){

            global $wpdb,$table_prefix;
            
            if(empty($_SESSION['order_id'])){

                $_SESSION['order_id']=time().rand(1000,9999);

            }
            

            $data=array(
                'bank'=>$bank,

                'name'=>$fullname,

                'email'=>$email,

                'mobile'=>$mobile,

                'description'=>$description,

                'amount'=>$amount,

                'order_id'=>$_SESSION['order_id'],

                'date'=>$date,

            );

                $_SESSION['bank']=$bank;

                $result=$wpdb->insert($table_prefix.'ezp_payments',$data,array('%s','%s','%s','%s','%s','%d') );



            if ($result){

                $_SESSION['pid']=$wpdb->insert_id;
                $_SESSION['amount']=$amount;



                if($bank=='zarinpal'){


                    zarinpal_request($data);

                }else{

                    faragate_request($data);

                }

            }

        }


    }


    ?>

    <div class="ezpay_wrawp">
        <?php switch ($status){
            case 0;
                include EZP_TPL_DIR.'html-user-form.php';
                break;
            case 1;
               // include EZP_TPL_DIR.'html-user-retutn.php';
               echo $return_result;
                break;
            default:
                include EZP_TPL_DIR.'html-user-form.php';
                break;

        } ?>


        </div>

<?php
}?>