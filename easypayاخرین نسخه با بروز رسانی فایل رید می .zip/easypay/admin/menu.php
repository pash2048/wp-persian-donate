<?php

add_action('admin_menu','ezp_admin_menu');

function ezp_admin_menu(){
    
    $main=add_menu_page('آسان پرداخت', 'آسان پرداخت','manage_options','ezp_main','ezp_main_function');
    $main_sub=  add_submenu_page('ezp_main','پرداخت ها','پرداخت ها', 'manage_options','ezp_main');
    $setting=add_submenu_page('ezp_main','تنظیمات','تنظیمات', 'manage_options','ezp_setting','ezp_settilng_page');

}